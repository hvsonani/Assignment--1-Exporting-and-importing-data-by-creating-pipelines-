-- Using Assignment Database--
Use Assignment;

--Creating Staging table in Assignment Database --

CREATE TABLE [dbo].[Staging_HumanResourcesEmployee]
(
	[BusinessEntityID] [varchar] (90) NOT NULL,
	[NationalIDNumber] [varchar](150) NOT NULL,
	[LoginID] [varchar](256) NOT NULL,
	[OrganizationNode] [varchar] (90) NULL,
	[OrganizationLevel]  [varchar] (100) Not NULL,
	[JobTitle] [varchar] (100) NOT NULL,
	[BirthDate] [varchar] (100) NOT NULL,
	[MaritalStatus] [varchar] (100) NOT NULL,
	[Gender] [varchar] (100) NOT NULL,
	[HireDate] [varchar] (100) NOT NULL,
	[SalariedFlag] [varchar] (100) NOT NULL,
	[VacationHours] [varchar] (100) NOT NULL,
	[SickLeaveHours] [varchar] (100) NOT NULL,
	[CurrentFlag] [varchar] (100) NOT NULL,
	[rowguid] [varchar] (100)  NOT NULL,
	[ModifiedDate] [varchar] (100) NOT NULL
)


-- Checking values imported into Staging table from flat file --

select* from Assignment.dbo.Staging_HumanResourcesEmployee;