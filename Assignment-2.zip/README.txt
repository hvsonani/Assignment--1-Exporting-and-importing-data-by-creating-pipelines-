
The zip folder contains the following files



1) Assignment-2.docx file documents output of three question 
  a)Creating SSIS package for exporting data to flat file 
  b)Script for creating Staging Table
  c)Creating SSIS package for importing data from flat file


2) employee.txt is a flat file which contains exported data from humanresources.employee table

\

3) SQLQuery contains script for creating Staging Table



4) Integration Services Project 2 folder contains SSIS package used to export data from humanresources.employee table to flat file



5) Integration Services Project 5 folder contains SSIS package used to import data from Flat file (employee.txt) file into 
   staging table (Staging_HumanResourcesEmployee)
